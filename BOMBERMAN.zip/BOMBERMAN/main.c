#include <stdlib.h>
#include <stdio.h>
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_mixer.h>
#include <pthread.h>
#include <unistd.h>

#include "jeu.h"
#include "constantes.h"


void jouer(SDL_Surface *ecran);

int main(int argc, char *argv[])
{
SDL_Surface *ecran=NULL;
SDL_Surface *menu=NULL;

SDL_Rect positionMenu;

SDL_Event event;
int continuer = 3;



SDL_Init(SDL_INIT_VIDEO);  //permet douvrir des videos

SDL_WM_SetIcon(IMG_Load("link.bmp"),NULL);
ecran = SDL_SetVideoMode(832,352,32,SDL_HWSURFACE | SDL_DOUBLEBUF);
SDL_WM_SetCaption("BOMBER MAN",NULL);



Mix_OpenAudio(44100,MIX_DEFAULT_FORMAT,MIX_DEFAULT_CHANNELS,1024);
Mix_Music *musique;
musique=Mix_LoadMUS("msc.mp3");

menu = IMG_Load("menu.png");  //Afficher le menu
positionMenu.x = 0;
positionMenu.y = 0;

Mix_PlayMusic(musique, -1);

while(continuer)
{
SDL_WaitEvent(&event);  //tant que ya rien qui se passe on attend l'evenement;

switch(event.type)
{case SDL_QUIT:
continuer=0;
break;


case SDL_KEYDOWN:

switch(event.key.keysym.sym)
{
case SDLK_ESCAPE:
continuer=0;
break;

case SDLK_1:    //Press 1 to play
jouer(ecran);
break;


}
break;

}

SDL_BlitSurface(menu,NULL,ecran,&positionMenu); //refrechir les images
SDL_Flip(ecran); //rafrechir lecran


}

SDL_CloseAudio();
SDL_FreeSurface(menu);
SDL_Quit();
return EXIT_SUCCESS;


}






























