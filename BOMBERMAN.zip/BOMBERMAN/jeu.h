#ifndef JEU_H_INCLUDED
#define JEU_H_INCLUDED

#include <stdbool.h>


typedef struct{
int key[SDLK_LAST] ;  //determiner la derniere touche appuyer
}Touches;

typedef struct {
    int x; // Position horizontale
    int y; // Position verticale
} Position;

int estAProximiteDesJoueurs(int x, int y);

void verifierFinDeJeu(int **carte, double ratiolink, double ratiolinkA);

void creation_bombe(int **carte, SDL_Surface* ecran,int joueur) ;
void *gestion_bombe(void*arg);
void sauvegarderJeu(int **carte, SDL_Rect positionJoueur, SDL_Rect positionJoueurA, double ratiolink, double ratiolinkA);
void chargerJeu(int ***carte, SDL_Rect *positionJoueur, SDL_Rect *positionJoueurA, double *ratiolink, double *ratiolinkA);

void UpdateClavier(Touches* etat_clavier);

void jouer(SDL_Surface* ecran);

void deplacerJoueur(int **carte,SDL_Rect *pos, int direction);

void chargerCarte(int **carte, const char* nomFichier);

void placementAleatoireObstacle(int **carte);

#endif // JEU_H_INCLUDED
