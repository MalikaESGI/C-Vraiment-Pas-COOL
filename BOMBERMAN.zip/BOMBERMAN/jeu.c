#include <stdlib.h>
#include <stdio.h>
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_mixer.h>
#include <time.h>
#include <unistd.h>
#include <pthread.h>
#include <SDL/SDL_ttf.h>
#include <stdbool.h>
#include "jeu.h"
#include "constantes.h"

//hello

typedef struct {
int **carte1;
SDL_Surface* ecran1;
int joueur;

}listearg;

listearg liste;


double compteurbombelink=0;
double destructionRocherlink=0;
double ratiolink=1;

double compteurbombelinkA=0;
double destructionRocherlinkA=0;
double ratiolinkA=1;



TTF_Font *police=NULL;
SDL_Surface *text=NULL;
SDL_Color couleurNoire={255,255,255},couleurOr={255,215,0};
char score[20]="";

SDL_Surface *textA=NULL;
char scoreA[20]="";


SDL_Rect positionbomberouge;

SDL_Rect positionBombe;
SDL_Rect positionBombeDroit;
SDL_Rect positionBombeGauche;
SDL_Rect positionBombeHaut;
SDL_Rect positionBombeBas;
SDL_Rect positionBombeCentre;


SDL_Rect positionwin;
SDL_Rect positionwinA;


void UpdateClavier(Touches* etat_clavier){ //fonction qui permet aux joueur de se deplacer au meme temps (deplacer les joueurs en cliquanat au meme temps sur les touches du clavier)


SDL_Event event;
while(SDL_PollEvent(&event))  {   //tant que la touche est appuier (levenemet est actif) //pollevent permet d'identifier la touche

switch(event.type){

case SDL_KEYDOWN:
etat_clavier->key[event.key.keysym.sym]=1; //si la touche est appuyer renvoie 1
break;


case SDL_KEYUP:
etat_clavier->key[event.key.keysym.sym]=0; //si la touche est relacher renvoie 0
break;

default:
break;

}
}
}



SDL_Rect position, positionJoueur;   //position de tous les elments,  positionJoueur:position du link
SDL_Rect positionA, positionJoueurA;



void chargerCarte(int **carte, const char* nomFichier) {
    FILE *fichier = fopen(nomFichier, "r");
    if (fichier == NULL) {
        fprintf(stderr, "Erreur lors de l'ouverture du fichier.\n");
        exit(EXIT_FAILURE);
    }

    for (int i = 0; i < 11; i++) {
        for (int j = 0; j < 26; j++) {
            fscanf(fichier, "%1d", &carte[i][j]);
        }
    }

    fclose(fichier);
}


int continuer;

void jouer (SDL_Surface *ecran)
{
Touches etat_clavier;
memset(&etat_clavier,0, sizeof(etat_clavier)); //memset permet de rendre letat  du clavier a zero


SDL_Surface *linkwin=NULL;
SDL_Surface *linkwinA=NULL;

SDL_Surface *link[4]={NULL};   //Les positions possible
SDL_Surface *linkA[4]={NULL};

SDL_Surface *linkActuel= NULL;   //position actuelle
SDL_Surface *linkActuelA= NULL;

SDL_Surface *mur=NULL;        //Telecharger le mur
SDL_Surface *obstacle=NULL;

SDL_Event event;

SDL_Surface *bombe=NULL;

SDL_Surface *bombedroit=NULL;
SDL_Surface *bombegauche=NULL;
SDL_Surface *bombehaut=NULL;
SDL_Surface *bombebas=NULL;
SDL_Surface *bombecentre=NULL;

SDL_Surface *bomberouge=NULL;



continuer=1;

int i=0,j=0;

//CARTE
int **carte=(int**)malloc(11*sizeof(int*));
for(i=0;i<11;i++)
{
carte[i]=(int*)malloc(26*sizeof(int));

}

chargerJeu(&carte, &positionJoueur, &positionJoueurA, &ratiolink, &ratiolinkA);


chargerCarte(carte, "carte.txt");  //chargement de la carte

linkwin=IMG_Load("linkwinA.png");
linkwinA=IMG_Load("linkwin.png");

mur = IMG_Load("mur.bmp");   //Charger les murs
obstacle = IMG_Load("obstacle.bmp");  //Charger les obstacles (murs a exploser)

bombe=IMG_Load("bombe.bmp");

bombecentre=IMG_Load("fire.bmp");
bombebas=IMG_Load("fire.bmp");
bombegauche=IMG_Load("fire.bmp");
bombedroit=IMG_Load("fire.bmp");
bombehaut=IMG_Load("fire.bmp");


bomberouge=IMG_Load("bomberouge.bmp");


link[BAS]=IMG_Load("link.bmp");
link[HAUT]=IMG_Load("link.bmp");
link[DROITE]=IMG_Load("link.bmp");
link[GAUCHE]=IMG_Load("link.bmp");


linkA[BAS]=IMG_Load("linkA.bmp");
linkA[HAUT]=IMG_Load("linkA.bmp");
linkA[DROITE]=IMG_Load("linkA.bmp");
linkA[GAUCHE]=IMG_Load("linkA.bmp");

linkActuel= link[BAS];
linkActuelA= linkA[BAS];


positionJoueur.x=3; //position du depart pour le premier link
positionJoueur.y=5;

positionJoueurA.x=22;  //position du depart pour le deuxieme link
positionJoueurA.y=5;

placementAleatoireObstacle(carte); //placer les obstacles aleatoirement sur la map

ratiolink=1;
ratiolinkA=1;

TTF_Init(); //initialiser la ttf

police = TTF_OpenFont("Coamei-Bold.ttf",26); //choisir la police
sprintf(score,"%.2f :LINK", ratiolink); //afficher le score
text=TTF_RenderText_Blended(police,score,couleurOr);


police = TTF_OpenFont("Coamei-Bold.ttf",26); //choisir la police
sprintf(scoreA,"%.2f :LINKA", ratiolinkA); //afficher le score
textA=TTF_RenderText_Blended(police,scoreA,couleurOr);

while(continuer==1)
{
{
UpdateClavier(&etat_clavier);  //verifier letat du clavier si une touche est appuyer on la determine et on deplace le joueur selon cette touche

if(etat_clavier.key[SDLK_UP]){
linkActuel=link[HAUT];
deplacerJoueur(carte, &positionJoueur,HAUT);

}

if(etat_clavier.key[SDLK_DOWN]){
linkActuel=link[BAS];
deplacerJoueur(carte, &positionJoueur,BAS);

}

if(etat_clavier.key[SDLK_RIGHT]){
linkActuel=link[DROITE];
deplacerJoueur(carte, &positionJoueur,DROITE);

}

if(etat_clavier.key[SDLK_LEFT]){
linkActuel=link[GAUCHE];
deplacerJoueur(carte, &positionJoueur,GAUCHE);

}

if(etat_clavier.key[SDLK_m]){   //La tocuhe m pour creer les bombes par le joueur1
creation_bombe(carte,ecran,1);
}

if(etat_clavier.key[SDLK_w]){
linkActuelA=linkA[HAUT];
deplacerJoueur(carte, &positionJoueurA,HAUT);

}

if(etat_clavier.key[SDLK_s]){
linkActuelA=linkA[BAS];
deplacerJoueur(carte, &positionJoueurA,BAS);

}

if(etat_clavier.key[SDLK_d]){
linkActuelA=linkA[DROITE];
deplacerJoueur(carte, &positionJoueurA,DROITE);

}

if(etat_clavier.key[SDLK_a]){
linkActuelA=linkA[GAUCHE];
deplacerJoueur(carte, &positionJoueurA,GAUCHE);

}

if(etat_clavier.key[SDLK_r]){
creation_bombe(carte,ecran,2);
}


if (etat_clavier.key[SDLK_ESCAPE] && !(continuer==5 || continuer==6)) {
    sauvegarderJeu(carte, positionJoueur, positionJoueurA, ratiolink, ratiolinkA);
    continuer = 0; // Optionnel: quitter le jeu après la sauvegarde
}

}

SDL_FillRect(ecran,NULL,SDL_MapRGB(ecran->format,0,0,0)); //quand in clique sur 1 lecran devient blanc

for(i=0;i<11;i++)
{for(j=0;j<26;j++)
{
position.x=j*TAILLE_BLOC;
position.y=i*TAILLE_BLOC;

switch(carte[i][j])
{
case MUR:
SDL_BlitSurface(mur, NULL, ecran, &position);
break;

case OBSTACLE:
SDL_BlitSurface(obstacle, NULL, ecran, &position);
break;

case BOMBE:
SDL_BlitSurface(bombe, NULL, ecran, &position);
break;

case BOMBECENTRE:
SDL_BlitSurface(bombecentre, NULL, ecran, &position);
break;

case BOMBEBAS:
SDL_BlitSurface(bombebas, NULL, ecran, &position);
break;

case BOMBEHAUT:
SDL_BlitSurface(bombehaut, NULL, ecran, &position);
break;

case BOMBEDROIT:
SDL_BlitSurface(bombedroit, NULL, ecran, &position);
break;

case BOMBEGAUCHE:
SDL_BlitSurface(bombegauche, NULL, ecran, &position);
break;


case BOMBEROUGE:
SDL_BlitSurface(bomberouge, NULL, ecran, &position);
break;
}
}
}

position.x=positionJoueur.x*TAILLE_BLOC;
position.y=positionJoueur.y*TAILLE_BLOC;
SDL_BlitSurface(linkActuel,NULL,ecran, &position);


positionA.x=positionJoueurA.x*TAILLE_BLOC;
positionA.y=positionJoueurA.y*TAILLE_BLOC;
SDL_BlitSurface(linkActuelA,NULL,ecran, &positionA);


usleep(80000);
SDL_Rect positionT;
positionT.x=200;
positionT.y=3;

SDL_BlitSurface(text,NULL,ecran,&positionT);

SDL_Rect positionTA;
positionTA.x=500;
positionTA.y=3;

SDL_BlitSurface(textA,NULL,ecran,&positionTA);

SDL_Flip(ecran);//rafrichir lecran

}

if(continuer==5)
{
Mix_CloseAudio();
Mix_OpenAudio(44100,MIX_DEFAULT_FORMAT,MIX_DEFAULT_CHANNELS,1024);
Mix_Music *gagner;
gagner=Mix_LoadMUS("gagner.mp3");
Mix_PlayMusic(gagner,0);
positionwin.x=300;
SDL_BlitSurface(linkwin,NULL,ecran,&positionwin); //affciher limage a lecran
SDL_Flip(ecran);
sleep(14);
continuer=0;  //fermer le jeu a la fin de la musique

}



if(continuer==6)
{

Mix_CloseAudio();
Mix_OpenAudio(44100,MIX_DEFAULT_FORMAT,MIX_DEFAULT_CHANNELS,1024);
Mix_Music *gagner;
gagner=Mix_LoadMUS("gagner.mp3");
Mix_PlayMusic(gagner,0);

positionwinA.x=300;
SDL_BlitSurface(linkwinA,NULL,ecran,&positionwinA); //affciher limage a lecran
SDL_Flip(ecran);
sleep(14);
continuer=0;  //fermer le jeu a la fin de la musique

}


//Liberer les surface qui ont etaient chargees
SDL_FreeSurface(mur);
SDL_FreeSurface(obstacle);

for(i=0;i<4;i++)
{SDL_FreeSurface(link[i]);
}

for(i=0;i<4;i++)
{SDL_FreeSurface(linkA[i]);
}

for (i = 0; i < 11; i++){
    free(carte[i]);
}

free(carte);

SDL_FreeSurface(bombe);
SDL_FreeSurface(bombecentre);
SDL_FreeSurface(bombebas);
SDL_FreeSurface(bombehaut);
SDL_FreeSurface(bombegauche);
SDL_FreeSurface(bombedroit);

SDL_FreeSurface(bomberouge);

SDL_FreeSurface(linkwin);
SDL_FreeSurface(linkwinA);
}


void deplacerJoueur(int **carte,SDL_Rect *pos, int direction)
{
switch(direction)
{

case HAUT:
if(carte[pos->y-1][pos->x]==MUR) //si le joueur croise un mur il arrete de bouger
{
break;
}

if(carte[pos->y-1][pos->x]==OBSTACLE) //si le joueur croise un obstacle il arrete de bouger
{
break;

}
pos->y--;  //si nn ordonnées demniue de 1
break;


case BAS:
if(carte[pos->y+1][pos->x]==MUR) //si le joueur croise un mur il arrete de bouger
{
break;
}
if(carte[pos->y+1][pos->x]==OBSTACLE) //si le joueur croise un obstacle il arrete de bouger
{
break;
}
pos->y++;
break;

case GAUCHE:
if(carte[pos->y][pos->x-1]==MUR)
{
break;

}
if(carte[pos->y][pos->x-1]==OBSTACLE)
{
break;

}
pos->x--;
break;

case DROITE:
if(carte[pos->y][pos->x+1]==MUR)
{
break;

}
if(carte[pos->y][pos->x+1]==OBSTACLE)
{
break;

}
pos->x++;
break;
}

}


void placementAleatoireObstacle(int **carte) {
    srand(time(NULL));

    for(int a = 3; a < 9; a++) {
        for(int b = 4; b < 22; b++) {
            if(carte[a][b] == 0 ) {   //verifier si la carte est vide
                    int v = rand() % 3;
                    if(v == 0) {
                        carte[a][b] = OBSTACLE;
                    }
                }
            }
        }
    }




void creation_bombe(int **carte, SDL_Surface* ecran,int joueur)
{
pthread_t thread1;

liste.carte1=carte;
liste.ecran1= ecran;
liste.joueur = joueur;

pthread_create(&thread1,NULL, gestion_bombe, (void* )&liste);   //creer un thread

}


void *gestion_bombe(void*arg){ //prend les element de la liste

int fin;

listearg *args=(listearg*)arg;
int **carte1 = args->carte1;

int joueur = args->joueur;  // Récupérer l'identifiant du joueur

    if (joueur == 1) {   //  déterminer la position de la bombe

       carte1[positionJoueur.y][positionJoueur.x] = BOMBE;

    } else if (joueur == 2) {

        carte1[positionJoueurA.y][positionJoueurA.x] = BOMBE;
    }


int a,b=0;


//Si le joueur depose une bombe le compteur augmente
if(carte1[positionJoueur.y][positionJoueur.x]==BOMBE)
{compteurbombelink=compteurbombelink+1;

}

if(carte1[positionJoueurA.y][positionJoueurA.x]==BOMBE)
{compteurbombelinkA=compteurbombelinkA+1;

}


/*
Mix_AllocateChannels(32);
Mix_Chunk *bruitbombe;
bruitbombe=Mix_LoadWAV("bruitbombe.mp3");
Mix_PlayChannel(2,bruitbombe,0);*/



for(a=2;a<11;a++)
{for(b=2;b<26;b++)
{

if(carte1[a][b]==BOMBE && joueur == 1)
{
 if(carte1[a][b-1]==OBSTACLE)
 {
  destructionRocherlink=destructionRocherlink+1;
 }

 if(carte1[a][b+1]==OBSTACLE)
 {

  destructionRocherlink=destructionRocherlink+1;
 }


 if(carte1[a-1][b]==OBSTACLE)
 {
  destructionRocherlink=destructionRocherlink+1;
 }


 if(carte1[a+1][b]==OBSTACLE)
 {
  destructionRocherlink=destructionRocherlink+1;
 }


}
}

}


for(a=2;a<11;a++)
{for(b=2;b<26;b++)
{

if(carte1[a][b]==BOMBE  && joueur == 2)
{
 if(carte1[a][b-1]==OBSTACLE)
 {
  destructionRocherlinkA=destructionRocherlinkA+1;
 }

 if(carte1[a][b+1]==OBSTACLE)
 {

  destructionRocherlinkA=destructionRocherlinkA+1;
 }


 if(carte1[a-1][b]==OBSTACLE)
 {
  destructionRocherlinkA=destructionRocherlinkA+1;
 }


 if(carte1[a+1][b]==OBSTACLE)
 {
  destructionRocherlinkA=destructionRocherlinkA+1;
 }


}
}

}



for(a=2;a<11;a++)
{for(b=2;b<26;b++){  //clignoter la bombe

if(carte1[a][b]==BOMBE)
{

carte1[a][b]=BOMBEROUGE;
usleep(200000);

carte1[a][b]=BOMBE;
usleep(200000);

carte1[a][b]=BOMBEROUGE;
usleep(200000);

carte1[a][b]=BOMBE;
usleep(200000);

}
}

}


for(a=2;a<11;a++)
{for(b=2;b<26;b++)
{
   if(carte1[a][b]==BOMBE)
   {

     carte1[a][b]=BOMBECENTRE;

     if(carte1[a][b] == carte1[positionJoueur.y][positionJoueur.x])
   {
      fin=2;
   }

    if(carte1[a][b] == carte1[positionJoueurA.y][positionJoueurA.x])
   {
      fin=1;
   }

   if(carte1[a+1][b] !=MUR)
   {
      carte1[a+1][b]=BOMBEBAS;
   }

   if(carte1[a+1][b] == carte1[positionJoueur.y][positionJoueur.x])
   {
      carte1[a+1][b]=BOMBEBAS;
      fin=2;
   }


   if(carte1[a+1][b] == carte1[positionJoueurA.y][positionJoueurA.x])
   {
      carte1[a+1][b]=BOMBEBAS;
      fin=1;
   }

   if(carte1[a+1][b] == OBSTACLE)
   {
      carte1[a+1][b]=BOMBEBAS;

   }


   if(carte1[a-1][b] !=MUR)
   {
      carte1[a-1][b]=BOMBEHAUT;
   }

   if(carte1[a-1][b] == carte1[positionJoueur.y][positionJoueur.x])
   {
      carte1[a-1][b]=BOMBEHAUT;
      fin=2;
   }


   if(carte1[a-1][b] == carte1[positionJoueurA.y][positionJoueurA.x])
   {
      carte1[a-1][b]=BOMBEHAUT;
      fin=1;
   }

   if(carte1[a-1][b] == OBSTACLE)
   {
      carte1[a-1][b]=BOMBEHAUT;
   }


   if(carte1[a][b+1] !=MUR)
   {
      carte1[a][b+1]=BOMBEDROIT;
   }

   if(carte1[a][b+1] == carte1[positionJoueur.y][positionJoueur.x])
   {
      carte1[a][b+1]=BOMBEDROIT;
      fin=2;
   }


   if(carte1[a][b+1] == carte1[positionJoueurA.y][positionJoueurA.x])
   {
      carte1[a][b+1]=BOMBEDROIT;
      fin=1;
   }

   if(carte1[a][b+1] == OBSTACLE)
   {
      carte1[a][b+1]=BOMBEDROIT;
   }

   if(carte1[a][b-1] !=MUR)
   {
      carte1[a][b-1]=BOMBEGAUCHE;
   }

   if(carte1[a][b-1] == carte1[positionJoueur.y][positionJoueur.x])
   {
      carte1[a][b-1]=BOMBEGAUCHE;
      fin=2;
   }


   if(carte1[a][b-1] == carte1[positionJoueurA.y][positionJoueurA.x])
   {
      carte1[a][b-1]=BOMBEGAUCHE;
      fin=1;
   }

   if(carte1[a][b-1] == OBSTACLE)
   {
      carte1[a][b-1]=BOMBEGAUCHE;
   }

   }



}



}

usleep(200000);
if (compteurbombelink != 0) {
    ratiolink = destructionRocherlink / compteurbombelink;
    sprintf(score,"%.2f :LINK",ratiolink);
    text=TTF_RenderText_Blended(police,score,couleurOr);
}

if (compteurbombelinkA != 0) {
ratiolinkA=destructionRocherlinkA/compteurbombelinkA;
sprintf(scoreA,"%.2f :LINKA",ratiolinkA);
textA=TTF_RenderText_Blended(police,scoreA,couleurOr);
}




for(a=2;a<11;a++)
{for(b=2;b<26;b++)
{

 if(carte1[a][b]==BOMBECENTRE)
 {
  carte1[a][b]=0;

 }

  if(carte1[a][b]==BOMBEBAS)
 {
  carte1[a][b]=0;

 }

  if(carte1[a][b]==BOMBEHAUT)
 {
  carte1[a][b]=0;

 }

  if(carte1[a][b]==BOMBEDROIT)
 {
  carte1[a][b]=0;

 }


  if(carte1[a][b]==BOMBEGAUCHE)
 {
  carte1[a][b]=0;

 }

}

}


bool tousLesMursDetruits = true;
for(int i = 2; i < 11; i++) {
    for(int j = 2; j < 26; j++) {
        if(carte1[i][j] == OBSTACLE) {
            tousLesMursDetruits = false;
            break;
        }
    }
    if(!tousLesMursDetruits) {
        break;
    }
}

if(tousLesMursDetruits) {
    if(ratiolink > ratiolinkA) {
        // Le joueur Link gagne
        continuer = 5;
    } else if(ratiolink < ratiolinkA) {

        continuer = 6;
    } else {

        continuer = 9; //egalite
    }
}


if(fin==2)
{
 continuer=5;
}

if(fin==1)
{
 continuer=6;
}



pthread_exit(NULL);







}



void sauvegarderJeu(int **carte, SDL_Rect positionJoueur, SDL_Rect positionJoueurA, double ratiolink, double ratiolinkA) {
    FILE *file = fopen("sauvegarde.txt", "w");
    if (file == NULL) {
        printf("Erreur lors de l'ouverture du fichier de sauvegarde\n");
        return;
    }

    // Sauvegarde de l'état de la carte
    for (int i = 0; i < 11; i++) {
        for (int j = 0; j < 26; j++) {
            fprintf(file, "%d ", carte[i][j]);
        }
        fprintf(file, "\n");
    }

    // Sauvegarde des positions des joueurs
    fprintf(file, "%d %d %d %d\n", positionJoueur.x, positionJoueur.y, positionJoueurA.x, positionJoueurA.y);

    // Sauvegarde des scores
    fprintf(file, "%.2f %.2f\n", ratiolink, ratiolinkA);

    fclose(file);
}




void chargerJeu(int ***carte, SDL_Rect *positionJoueur, SDL_Rect *positionJoueurA, double *ratiolink, double *ratiolinkA) {
    FILE *file = fopen("sauvegarde.txt", "r");
    if (file == NULL) {
        printf("Aucune sauvegarde trouvée, démarrage d'un nouveau jeu\n");
        return;
    }

    // Chargement de l'état de la carte
    *carte = (int **)malloc(11 * sizeof(int *));
    for (int i = 0; i < 11; i++) {
        (*carte)[i] = (int *)malloc(26 * sizeof(int));
        for (int j = 0; j < 26; j++) {
            fscanf(file, "%d", &(*carte)[i][j]);
        }
    }

    // Chargement des positions des joueurs
    fscanf(file, "%hd %hd %hd %hd", &positionJoueur->x, &positionJoueur->y, &positionJoueurA->x, &positionJoueurA->y);


    // Chargement des scores
    fscanf(file, "%lf %lf", ratiolink, ratiolinkA);

    fclose(file);
}



















